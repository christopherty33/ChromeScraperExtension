chrome.runtime.onInstalled.addListener(() => {
    console.log("Web Scraper Extension Installed");
});